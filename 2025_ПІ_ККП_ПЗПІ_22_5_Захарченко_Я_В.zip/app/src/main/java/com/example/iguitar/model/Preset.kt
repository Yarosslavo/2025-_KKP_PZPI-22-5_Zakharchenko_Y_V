package com.example.iguitar.model

data class Preset(
    val id: Int,
    val title: String,
    val user: Int,
    val created_at: String,
    val preset_effects: List<PresetEffect>
)

data class PresetEffect(
    val effect: Effect,
    val parameters: Map<String, Double>
)
