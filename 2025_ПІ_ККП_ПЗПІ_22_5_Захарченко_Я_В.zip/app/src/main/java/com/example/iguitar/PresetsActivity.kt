package com.example.iguitar

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer

class PresetsActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var isPlaying = false

    private lateinit var tvTrackName: TextView
    private lateinit var tvEffectName: TextView
    private lateinit var tvLikes: TextView
    private lateinit var btnLikeHeart: TextView
    private lateinit var btnPlayPause: TextView
    private lateinit var etComment: EditText
    private lateinit var btnSendComment: Button
    private lateinit var seekBar: SeekBar

    private var liked = false
    private var likesCount = 0

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_presets)

        tvTrackName = findViewById(R.id.tv_track_name)
        tvEffectName = findViewById(R.id.tv_effect_name)
        tvLikes = findViewById(R.id.tv_likes)
        btnLikeHeart = findViewById(R.id.btn_like_heart)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        etComment = findViewById(R.id.et_comment)
        btnSendComment = findViewById(R.id.btn_send_comment)
        seekBar = findViewById(R.id.seek_bar)

        tvTrackName.text = "Dream Song"
        tvEffectName.text = "Distortion"

        likesCount = 2
        tvLikes.text = likesCount.toString()
        updateHeartUi()

        btnLikeHeart.setOnClickListener {
            liked = !liked
            likesCount += if (liked) 1 else -1
            if (likesCount < 0) likesCount = 0
            tvLikes.text = likesCount.toString()
            updateHeartUi()
        }

        btnPlayPause.setOnClickListener {
            togglePlayPause()
        }

        btnSendComment.setOnClickListener {
            val comment = etComment.text.toString().trim()
            if (comment.isNotEmpty()) {
                Toast.makeText(this, "Комментарий отправлен: $comment", Toast.LENGTH_SHORT).show()
                etComment.text.clear()
            } else {
                Toast.makeText(this, "Введите комментарий", Toast.LENGTH_SHORT).show()
            }
        }

        initPlayer()
    }

    private fun updateHeartUi() {
        btnLikeHeart.setTextColor(if (liked) Color.RED else Color.parseColor("#B0B0B0"))
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build()
        val maybeUrl: String? = intent.getStringExtra("audio_url")
        val mediaItem = if (!maybeUrl.isNullOrBlank()) {
            MediaItem.fromUri(Uri.parse(maybeUrl))
        } else {
            MediaItem.fromUri(RawResourceDataSource.buildRawResourceUri(R.raw.sample))
        }
        player?.setMediaItem(mediaItem)
        player?.prepare()

        // обновление прогресса
        handler.post(object : Runnable {
            override fun run() {
                player?.let { p ->
                    seekBar.max = p.duration.toInt().coerceAtLeast(1)
                    seekBar.progress = p.currentPosition.toInt()
                }
                handler.postDelayed(this, 500)
            }
        })

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    player?.seekTo(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
            btnPlayPause.text = "▶"
        } else {
            p.play()
            btnPlayPause.text = "⏸"
        }
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
        isPlaying = false
    }
}
