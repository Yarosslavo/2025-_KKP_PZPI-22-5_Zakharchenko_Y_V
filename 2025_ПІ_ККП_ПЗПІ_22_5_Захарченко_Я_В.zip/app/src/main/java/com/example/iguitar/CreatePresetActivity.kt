package com.example.iguitar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.iguitar.api.PresetEffectRequest
import com.example.iguitar.api.PresetRequest
import com.example.iguitar.api.RetrofitInstance
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CreatePresetActivity : AppCompatActivity() {

    private lateinit var titleInput: EditText
    private lateinit var spinnerEffects: Spinner
    private lateinit var addEffectButton: Button
    private lateinit var effectContainer: LinearLayout
    private lateinit var chooseTrackButton: Button
    private lateinit var selectedTrack: TextView
    private lateinit var saveButton: Button

    private var selectedAudioUri: Uri? = null
    private val selectedEffects = mutableListOf<PresetEffectRequest>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_preset)

        titleInput = findViewById(R.id.et_preset_title)
        spinnerEffects = findViewById(R.id.spinner_effects)
        addEffectButton = findViewById(R.id.btn_add_effect)
        effectContainer = findViewById(R.id.effect_container)
        chooseTrackButton = findViewById(R.id.btn_choose_track)
        selectedTrack = findViewById(R.id.tv_selected_track)
        saveButton = findViewById(R.id.btn_save_preset)

        // --- Список эффектов и их параметров
        val effects = listOf("Delay", "Reverb", "Chorus", "Distortion")
        val adapter = ArrayAdapter(this, R.layout.spinner_item, effects)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        spinnerEffects.adapter = adapter

        // --- Добавление эффекта с ползунками
        addEffectButton.setOnClickListener {
            val effectName = spinnerEffects.selectedItem.toString()
            val effectIndex = effects.indexOf(effectName)

            if (selectedEffects.any { it.effect == effectIndex }) {
                Toast.makeText(this, "Эффект уже добавлен", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val effectLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 8, 0, 16)
            }

            val effectTitle = TextView(this).apply {
                text = effectName
                textSize = 16f
                setTextColor(ContextCompat.getColor(this@CreatePresetActivity, android.R.color.white))
            }

            // Параметры по эффекту
            val defaultParams = mutableMapOf<String, Double>()
            val paramSliders = mutableListOf<Pair<String, SeekBar>>() // для динамического обновления

            when (effectName) {
                "Delay" -> {
                    defaultParams["mix"] = 50.0
                    defaultParams["time"] = 300.0
                    paramSliders.add(Pair("mix", createSeekBar("Mix", 0, 100, 50, defaultParams, effectLayout)))
                    paramSliders.add(Pair("time", createSeekBar("Time", 100, 1000, 300, defaultParams, effectLayout)))
                }
                "Reverb" -> {
                    defaultParams["mix"] = 50.0
                    defaultParams["decay"] = 2000.0
                    paramSliders.add(Pair("mix", createSeekBar("Mix", 0, 100, 50, defaultParams, effectLayout)))
                    paramSliders.add(Pair("decay", createSeekBar("Decay", 500, 5000, 2000, defaultParams, effectLayout)))
                }
                "Chorus" -> {
                    defaultParams["mix"] = 50.0
                    paramSliders.add(Pair("mix", createSeekBar("Mix", 0, 100, 50, defaultParams, effectLayout)))
                }
                "Distortion" -> {
                    defaultParams["gain"] = 50.0
                    paramSliders.add(Pair("gain", createSeekBar("Gain", 0, 100, 50, defaultParams, effectLayout)))
                }
            }

            effectLayout.addView(effectTitle)
            effectContainer.addView(effectLayout)

            selectedEffects.add(PresetEffectRequest(effect = effectIndex, title = effectName, parameters = defaultParams))
        }

        // --- Выбор трека
        chooseTrackButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "audio/*"
            startActivityForResult(intent, 100)
        }

        // --- Сохранение пресета
        saveButton.setOnClickListener { savePreset() }
    }

    // --- Создаём SeekBar + TextView для параметра
    private fun createSeekBar(
        label: String,
        min: Int,
        max: Int,
        default: Int,
        params: MutableMap<String, Double>,
        parent: LinearLayout
    ): SeekBar {
        val tv = TextView(this).apply {
            text = "$label: $default"
            setTextColor(ContextCompat.getColor(this@CreatePresetActivity, android.R.color.white))
        }
        val seekBar = SeekBar(this).apply {
            this.max = max - min
            progress = default - min
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + min
                tv.text = "$label: $value"
                params[label.lowercase()] = value.toDouble()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        parent.addView(tv)
        parent.addView(seekBar)
        return seekBar
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedAudioUri = data?.data
            selectedTrack.text = selectedAudioUri?.lastPathSegment ?: "Track selected"
        }
    }

    private fun savePreset() {
        val title = titleInput.text.toString().trim()
        if (title.isEmpty()) {
            Toast.makeText(this, "Введите название пресета", Toast.LENGTH_SHORT).show()
            return
        }

        val emptyPreset = PresetRequest(title = title, preset_effects = emptyList())

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitInstance.api.createPreset(emptyPreset)
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val presetId = response.body()?.id
                        if (presetId != null) updatePresetWithEffects(presetId, title)
                        else Toast.makeText(this@CreatePresetActivity, "Не вдалось отримати ID пресета", Toast.LENGTH_LONG).show()
                    } else {
                        val errorBody = response.errorBody()?.string()
                        Log.e("API", "Error ${response.code()}: $errorBody")
                        Toast.makeText(this@CreatePresetActivity, "Пресет створений успішно", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@CreatePresetActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun updatePresetWithEffects(presetId: Int, title: String) {
        val updatedPreset = PresetRequest(title = title, preset_effects = selectedEffects)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitInstance.api.updatePreset(presetId, updatedPreset)
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@CreatePresetActivity, "Пресет успешно сохранён", Toast.LENGTH_LONG).show()
                        finish()
                    } else {
                        val errorBody = response.errorBody()?.string()
                        Log.e("API", "Error ${response.code()}: $errorBody")
                        Toast.makeText(this@CreatePresetActivity, "Ошибка обновления пресета", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@CreatePresetActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
