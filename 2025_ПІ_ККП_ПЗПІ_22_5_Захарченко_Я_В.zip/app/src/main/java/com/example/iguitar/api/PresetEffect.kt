package com.example.iguitar.api

data class PresetRequest(
    val title: String,
    val preset_effects: List<PresetEffectRequest>
)

data class PresetEffectRequest(
    val effect: Int,
    val title: String, // добавляем title
    val parameters: MutableMap<String, Double> = mutableMapOf()
)

data class PresetResponse(
    val id: Int,
    val title: String,
    val preset_effects: List<PresetEffectResponse>?
)

data class PresetEffectResponse(
    val effect: Int,
    val title: String?,
    val parameters: Map<String, Double>?
)
