package com.example.iguitar.model

data class Effect(
    val id: Int,
    val name: String?,
    val description: String?,
    val default_parameters: Map<String, Any>
)
