package com.example.iguitar.api

data class Track(
    val id: Int,
    val name: String
)
