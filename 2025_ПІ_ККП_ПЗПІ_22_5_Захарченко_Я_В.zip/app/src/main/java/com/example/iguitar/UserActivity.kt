package com.example.iguitar

import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class UserActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        val username = intent.getStringExtra("username") ?: "User"
        val tvUsername = findViewById<TextView>(R.id.tv_username)
        tvUsername.text = username

        val footer = findViewById<TextView>(R.id.footer_user)
        footer.text = Html.fromHtml(
            "Copyright © 2020, <font color='#9C27B0'>Fotogram</font> | All Right Reserved",
            Html.FROM_HTML_MODE_LEGACY
        )

        // 🚪 Logout
        val logoutBtn = findViewById<Button>(R.id.btn_logout)
        logoutBtn.setOnClickListener {
            val prefs = getSharedPreferences("auth", MODE_PRIVATE)
            prefs.edit().clear().apply()

            val intent = Intent(this@UserActivity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // 📂 Переход в список пресетов
        val presetsBtn = findViewById<Button>(R.id.btn_my_presets)
        presetsBtn.setOnClickListener {
            val intent = Intent(this@UserActivity, PresetsActivity::class.java)
            startActivity(intent)
        }

        // 🎸 Переход в создание пресета
        val createPresetBtn = findViewById<Button>(R.id.btn_create_preset)
        createPresetBtn.setOnClickListener {
            val intent = Intent(this@UserActivity, CreatePresetActivity::class.java)
            startActivity(intent)
        }
    }
}
