package com.example.iguitar.api

import retrofit2.Response
import retrofit2.http.*
import com.example.iguitar.model.Effect
import okhttp3.ResponseBody

data class AuthToken(
    val token: String
)

interface ApiService {

    @FormUrlEncoded
    @POST("api/login/")
    suspend fun authUser(
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("title") title: String
    ): Response<AuthToken>

    @POST("api/presets/")
    suspend fun createPreset(@Body presetRequest: PresetRequest): Response<PresetResponse>

    @PUT("api/presets/{id}/")
    suspend fun updatePreset(@Path("id") id: Int, @Body presetRequest: PresetRequest): Response<PresetResponse>

    @PATCH("api/presets/{id}/")
    suspend fun updatePreset(
        @Path("id") presetId: Int,
        @Body preset: PresetRequest,
        @Header("Authorization") token: String
    ): Response<PresetResponse>

    @POST("api/logout/")
    suspend fun logout(): Response<Unit>

    @GET("api/effects/")
    suspend fun getEffects(): Response<List<Effect>>
}
