package com.example.iguitar

import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.iguitar.api.AuthToken
import com.example.iguitar.api.RetrofitInstance
import kotlinx.coroutines.launch
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val btnBack = findViewById<Button>(R.id.btn_back)
        val btnConfirm = findViewById<Button>(R.id.btn_confirm)
        val etUsername = findViewById<EditText>(R.id.et_username)
        val etPassword = findViewById<EditText>(R.id.et_password)

        btnBack.setOnClickListener {
            finish() // Закрывает LoginActivity и возвращает на MainActivity
        }

        btnConfirm.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Введите имя пользователя и пароль", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                try {
                    val response: Response<AuthToken> =
                        RetrofitInstance.api.authUser(username, password, "someTitle")

                    if (response.isSuccessful) {
                        val authToken = response.body()

                        if (authToken == null) {
                            Toast.makeText(this@LoginActivity, "Ошибка: тело ответа пустое", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        val token = authToken.token
                        if (token.isNullOrEmpty()) {
                            Toast.makeText(this@LoginActivity, "Ошибка: токен пустой", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        // ✅ Сохраняем токен
                        val prefs = getSharedPreferences("auth", MODE_PRIVATE)
                        prefs.edit().putString("token", token).apply()

                        // Обновляем футер
                        val footer = findViewById<TextView>(R.id.footer_login)
                        footer.text = Html.fromHtml(
                            "Copyright © 2020, <font color='#9C27B0'>Fotogram</font> | All Right Reserved",
                            Html.FROM_HTML_MODE_LEGACY
                        )

                        // Переход к UserActivity
                        val intent = Intent(this@LoginActivity, UserActivity::class.java)
                        intent.putExtra("username", username)
                        intent.putExtra("token", token)
                        startActivity(intent)
                        finish()

                    } else {
                        if (response.code() == 503) {
                            Toast.makeText(this@LoginActivity, "Сервер временно недоступен (503). Повторите позже.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@LoginActivity, "Ошибка сервера: ${response.code()}", Toast.LENGTH_LONG).show()
                        }
                    }

                } catch (e: Exception) {
                    Toast.makeText(this@LoginActivity, "Ошибка входа: ${e.message}", Toast.LENGTH_LONG).show()
                    e.printStackTrace()
                }
            }
        }
    }
}
